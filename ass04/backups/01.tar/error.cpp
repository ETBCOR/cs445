#include "error.h"

void throwErr (ErrCode err, Node * node, Node * found)
{
    switch (err) {
        case VAR_AS_FUN:
            printf("ERROR(%d): '%s' is a simple variable and cannot be called.\n",
                   node->linenum, ((VarDecl *)node)->name); break;
        case ARR_MISMATCH:
            printf("ERROR(%d): '%s' requires both operands be arrays or not but lhs is%s an array and rhs is%s an array.\n",
                   node->linenum, ((Op *)node)->opName, node->child[0]->isArray ? "" : " not", node->child[1]->isArray ? "" : " not"); break;
        case OP_LHS:
            printf("ERROR(%d): '%s' requires operands of type %s but lhs is of type %s.\n",
                   node->linenum, ((Op *)node)->opName, node->type, node->child[0]->type); break;
        case OP_RHS:
            printf("ERROR(%d): '%s' requires operands of type %s but rhs is of type %s.\n",
                   node->linenum, ((Op *)node)->opName, node->type, node->child[1]->type); break;
        case OPERAND_MISMATCH:
            printf("ERROR(%d): '%s' requires operands of the same type but lhs is type %s and rhs is type %s.\n",
                   node->linenum, ((Op *)node)->opName, node->child[0]->type, node->child[1]->type); break;
        case ARR_NONINT_INDEX:
            printf("ERROR(%d): Array '%s' should be indexed by type int but got type %s.\n",
                   node->linenum, ((VarDecl *)node->child[0])->name, node->child[1]->type); break;
        case ARR_UNINDEXED:
            printf("ERROR(%d): Array index is the unindexed array '%s'.\n",
                   node->linenum, ((VarDecl *)node->child[1])->name); break;
        case LOOPLESS_BREAK:
            printf("ERROR(%d): Cannot have a break statement outside of loop.\n",
                   node->linenum); break;
        case NON_ARR_INDEX:
            printf("ERROR(%d): Cannot index nonarray '%s'.\n",
                   node->linenum, ((VarDecl *)node->child[0])->name); break;
        case ARR_RETURN:
            printf("ERROR(%d): Cannot return an array.\n",
                   node->linenum); break;
        case ARR_COND:
            printf("ERROR(%d): Cannot use array as test condition in %s statement.\n",
                   node->linenum); break;
        case ARR_RANGE:
            printf("ERROR(%d): Cannot use array in position %d in range of for statement.\n",
                   node->linenum); break;
        case FUN_AS_VAR:
            printf("ERROR(%d): Cannot use function '%s' as a variable.\n",
                   node->linenum, ((VarDecl *)node)->name); break;
        case PARM_TYPE:
            printf("ERROR(%d): Expecting %s in parameter %i of call to '%s' declared on line %d butgot %s.\n",
                   node->linenum); break;
        case RANGE_TYPE:
            printf("ERROR(%d): Expecting %s in position %d in range of for statement but got %s.\n",
                   node->linenum); break;
        case NONBOOL_COND:
            printf("ERROR(%d): Expecting Boolean test condition in %s statement but got %s.\n",
                   node->linenum); break;
        case PARM_NONARR:
            printf("ERROR(%d): Expecting array in parameter %i of call to '%s' declared on line %d.\n",
            node->linenum); break;
        case RETURN_VALUED:
            printf("ERROR(%d): Function '%s' at line %d is expecting no return value, but return has a value.\n",
            node->linenum); break;
        case RETURN_UNVALUED:
            printf("ERROR(%d): Function '%s' at line %d is expecting to return %s but return has no value.\n",
                   node->linenum); break;
        case RETURN_MISMATCH:
            printf("ERROR(%d): Function '%s' at line %d is expecting to return %s but returns %s.\n",
                   node->linenum); break;
        case INIT_NONCONST:
            printf("ERROR(%d): Initializer for variable '%s' is not a constant expression.\n",
                   node->linenum); break;
        case INIT_MISMATCH:
            printf("ERROR(%d): Initializer for variable '%s' of %s is of %s\n",
                   node->linenum); break;
        case INIT_ARR_MISMATCH:
            printf("ERROR(%d): Initializer for variable '%s' requires both operands be arrays or not but variable is%s an array and rhs is%s an array.\n",
                   node->linenum); break;
        case PARM_ARR:
            printf("ERROR(%d): Not expecting array in parameter %i of call to '%s' declared on line %d.\n",
                   node->linenum); break;
        case DECL_DBL:
            printf("ERROR(%d): Symbol '%s' is already declared at line %d.\n",
                   node->linenum, ((VarDecl *)node)->name, found->linenum); break;
        case DECL_NOT:
            printf("ERROR(%d): Symbol '%s' is not declared.\n",
                   node->linenum, ((VarDecl *)node)->name); break;
        case OP_ARR:
            printf("ERROR(%d): The operation '%s' does not work with arrays.\n",
                   node->linenum, ((Op *)node)->opName); break;
        case OP_NONARR:
            printf("ERROR(%d): The operation '%s' only works with arrays.\n",
                   node->linenum, ((Op *)node)->opName); break;
        case PARM_FEW:
            printf("ERROR(%d): Too few parameters passed for function '%s' declared on line %d.\n",
                   node->linenum); break;
        case PARM_MANY:
            printf("ERROR(%d): Too many parameters passed for function '%s' declared on line %d.\n",
                   node->linenum); break;
        case OPERAND_UNARY:
            printf("ERROR(%d): Unary '%s' requires an operand of type %s but was given type %s.\n",
                   node->linenum, ((Op *)node)->opName, node->type, node->child[0]->type); break;
        case NO_MAIN:
            printf("ERROR(LINKER): A function named 'main' with no parameters must be defined.\n"); break;
    }
    errCount++;
}

void throwWrn (WrnCode wrn, Node * node, Node * found)
{
    switch (wrn) {
        case NO_RETURN:
            printf("WARNING(%d): Expecting to return %s but function '%s' has no return statement.\n",
                   node->linenum); break;
        case FUN_UNUSED:
            printf("WARNING(%d): The function '%s' seems not to be used.\n",
                   node->linenum); break;
        case PARM_UNUSED:
            printf("WARNING(%d): The parameter '%s' seems not to be used.\n",
                   node->linenum); break;
        case VAR_UNUSED:
            printf("WARNING(%d): The variable '%s' seems not to be used.\n",
                   node->linenum, ((VarDecl *)node)->name);
            ((VarDecl *)node)->usageWrnFlg = true;
            break;
        case VAR_UNINITED:
            printf("WARNING(%d): Variable '%s' may be uninitialized when used here.\n",
                   node->linenum, ((VarDecl *)node)->name);
            ((VarDecl *)found)->usageWrnFlg = true;
            break;
    }
    wrnCount++;
}

void wrnUnused(std::string symbol, void * node_)
{
    VarDecl * node = (VarDecl *) node_;
    if(!node->isFun && !node->usageFlg && !node->usageWrnFlg) throwWrn(VAR_UNUSED, node);
}

