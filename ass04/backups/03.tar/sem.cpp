#include "sem.h"

static TokenData * buildTkn(char *);

void analyze(Node * tree, SymbolTable * tbl)
{
    Parm * pi = new Parm(buildTkn((char *)"pi"), false);
    pi->type = (char *)"int";
    FunDecl * output  = new FunDecl(buildTkn((char *)"output" ), pi, NULL);
    tbl->insert(output->name, output);

    Parm * pb = new Parm(buildTkn((char *)"pb"), false);
    pb->type = (char *)"bool";
    FunDecl * outputb = new FunDecl(buildTkn((char *)"outputb"), pb, NULL);
    tbl->insert(outputb->name, outputb);

    Parm * pc = new Parm(buildTkn((char *)"pc"), false);
    pc->type = (char *)"char";
    FunDecl * outputc = new FunDecl(buildTkn((char *)"outputc"), pc, NULL);
    tbl->insert(outputc->name, outputc);

    FunDecl * input  = new FunDecl(buildTkn((char *)"int" ), buildTkn((char *)"input" ), NULL, NULL);
    tbl->insert(input->name, input);

    FunDecl * inputb = new FunDecl(buildTkn((char *)"bool"), buildTkn((char *)"inputb"), NULL, NULL);
    tbl->insert(inputb->name, inputb);

    FunDecl * inputc = new FunDecl(buildTkn((char *)"char"), buildTkn((char *)"inputc"), NULL, NULL);
    tbl->insert(inputc->name, inputc);

    FunDecl * outnl = new FunDecl(buildTkn((char *)"outnl"), NULL, NULL);
    tbl->insert(outnl->name, outnl);

    tree->sem(tbl);

    Node * m = (Node *)tbl->lookupGlobal("main");
    if (!m || !((VarDecl *)m)->isFun || m->child[0])
        throwErr(NO_MAIN, NULL);
}

static TokenData * buildTkn(char * name)
{
    TokenData * t = new TokenData;
    t->linenum = -1;
    t->tokenstr = strdup(name);
    t->svalue = strdup(name);
    return t;
}
